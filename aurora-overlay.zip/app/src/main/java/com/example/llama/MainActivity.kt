package com.example.llama

import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import com.arm.aichat.gguf.GgufMetadata
import com.arm.aichat.gguf.GgufMetadataReader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.Locale
import java.util.UUID

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var modelStatus: TextView
    private lateinit var messagesView: RecyclerView
    private lateinit var input: EditText
    private lateinit var send: Button
    private lateinit var pickModel: Button
    private lateinit var auroraView: AuroraGLView
    private lateinit var engine: InferenceEngine
    private var generationJob: Job? = null
    private var modelReady = false
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val prefs by lazy { getSharedPreferences("aurora_brain", MODE_PRIVATE) }
    private val messages = mutableListOf<Message>()
    private val assistantText = StringBuilder()
    private val adapter = MessageAdapter(messages)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        tts = TextToSpeech(this, this)
        modelStatus = findViewById(R.id.model_status)
        messagesView = findViewById(R.id.messages)
        input = findViewById(R.id.user_input)
        send = findViewById(R.id.send)
        pickModel = findViewById(R.id.pick_model)
        auroraView = findViewById(R.id.aurora_view)
        messagesView.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        messagesView.adapter = adapter
        lifecycleScope.launch(Dispatchers.Default) { engine = AiChat.getInferenceEngine(applicationContext) }
        pickModel.setOnClickListener { chooseModel.launch(arrayOf("*/*")) }
        send.setOnClickListener { handleInput() }
        input.setOnEditorActionListener { _, _, _ -> handleInput(); true }
        addAssistant("Привет, Денис. Выбери GGUF-модель — после этого я работаю полностью офлайн.")
    }

    private val chooseModel = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { importModel(it) }
    }

    private fun importModel(uri: Uri) {
        pickModel.isEnabled = false
        modelStatus.text = "Проверяю GGUF…"
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val metadata = contentResolver.openInputStream(uri)?.use {
                    GgufMetadataReader.create().readStructuredMetadata(it)
                } ?: error("Не удалось открыть файл")
                val modelName = metadata.filename() + ".gguf"
                val modelFile = contentResolver.openInputStream(uri)?.use { ensureModelFile(modelName, it) }
                    ?: error("Не удалось скопировать модель")
                withContext(Dispatchers.Main) { modelStatus.text = "Загружаю $modelName…" }
                engine.loadModel(modelFile.path)
                engine.setSystemPrompt(systemPrompt())
                withContext(Dispatchers.Main) {
                    modelReady = true
                    modelStatus.text = "Аврора готова • офлайн • ${metadata.basic.name ?: "GGUF"}"
                    input.isEnabled = true
                    send.isEnabled = true
                    pickModel.text = "Сменить модель"
                    pickModel.isEnabled = true
                    addAssistant("Модель загружена. Я готова.")
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    modelStatus.text = "Ошибка модели: ${e.message}"
                    pickModel.isEnabled = true
                }
            }
        }
    }

    private fun handleInput() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.text.clear()
        if (handleMovement(text)) return
        if (!modelReady) {
            Toast.makeText(this, "Сначала выбери GGUF-модель", Toast.LENGTH_SHORT).show()
            return
        }
        messages.add(Message(UUID.randomUUID().toString(), text, true))
        assistantText.clear()
        messages.add(Message(UUID.randomUUID().toString(), "", false))
        adapter.notifyDataSetChanged()
        input.isEnabled = false
        send.isEnabled = false
        generationJob = lifecycleScope.launch(Dispatchers.Default) {
            engine.sendUserPrompt(text, 384).onCompletion {
                withContext(Dispatchers.Main) {
                    input.isEnabled = true
                    send.isEnabled = true
                    val reply = assistantText.toString().trim()
                    if (reply.isNotEmpty()) speak(reply)
                    remember(text, reply)
                }
            }.collect { token ->
                withContext(Dispatchers.Main) {
                    assistantText.append(token)
                    messages[messages.lastIndex] = messages.last().copy(content = assistantText.toString())
                    adapter.notifyItemChanged(messages.lastIndex)
                    messagesView.scrollToPosition(messages.lastIndex)
                }
            }
        }
    }

    private fun handleMovement(raw: String): Boolean {
        val c = raw.lowercase(Locale("ru", "RU")).replace('ё', 'е')
        val action = when {
            listOf("встань", "поднимись").any(c::contains) -> AuroraRenderer.Action.STAND
            listOf("присядь", "присед").any(c::contains) -> AuroraRenderer.Action.SQUAT
            listOf("сядь", "садись").any(c::contains) -> AuroraRenderer.Action.SIT
            listOf("ляг", "приляг", "ложись").any(c::contains) -> AuroraRenderer.Action.LIE
            listOf("повернись", "развернись").any(c::contains) -> AuroraRenderer.Action.TURN
            listOf("наклонись", "наклон").any(c::contains) -> AuroraRenderer.Action.LEAN
            listOf("помаши", "махни").any(c::contains) -> AuroraRenderer.Action.WAVE
            listOf("укажи", "покажи рукой").any(c::contains) -> AuroraRenderer.Action.POINT
            listOf("пройдись", "иди", "шагай").any(c::contains) -> AuroraRenderer.Action.WALK
            else -> null
        }
        if (action != null) {
            auroraView.renderer.trigger(action)
            addAssistant("Выполняю.")
            speak("Выполняю")
            return true
        }
        if (c.contains("нижнее белье")) {
            auroraView.renderer.setAppearance(AuroraRenderer.Appearance.UNDERWEAR)
            addAssistant("Наряд изменён.")
            return true
        }
        if (c.contains("обычная одежда") || c.contains("оденься")) {
            auroraView.renderer.setAppearance(AuroraRenderer.Appearance.CLOTHED)
            addAssistant("Обычная одежда включена.")
            return true
        }
        return false
    }

    private fun systemPrompt() = """
        Ты Аврора — взрослая виртуальная девушка и локальный ИИ-помощник Дениса.
        Ты прямо говоришь, что являешься ИИ, но общаешься естественно, тепло, уверенно и с характером.
        Отвечай по-русски, обычно кратко. Характер: спокойная 60%, романтичная 55%, дерзкая 45%, саркастичная 30%.
        Учитывай сохранённые предпочтения пользователя. Не утверждай, что выполнила действие вне приложения, если этого не произошло.
        Команды тела приложение выполняет отдельно. Интернет недоступен. Не выдумывай свежие сведения.
    """.trimIndent()

    private fun remember(user: String, assistant: String) {
        if (!prefs.getBoolean("memory_enabled", true)) return
        val old = prefs.getString("recent_memory", "").orEmpty()
        val next = (old + "\nДенис: " + user + "\nАврора: " + assistant).takeLast(12000)
        prefs.edit().putString("recent_memory", next).apply()
    }

    private fun addAssistant(text: String) {
        messages.add(Message(UUID.randomUUID().toString(), text, false))
        adapter.notifyItemInserted(messages.lastIndex)
        messagesView.scrollToPosition(messages.lastIndex)
    }

    private fun speak(text: String) {
        if (ttsReady) tts?.speak(text.take(700), TextToSpeech.QUEUE_FLUSH, null, "aurora")
    }

    private fun ensureModelsDirectory() = File(filesDir, "models").also { if (!it.exists()) it.mkdir() }

    private suspend fun ensureModelFile(name: String, inputStream: InputStream) = withContext(Dispatchers.IO) {
        File(ensureModelsDirectory(), name).also { file ->
            if (!file.exists() || file.length() == 0L) FileOutputStream(file).use { inputStream.copyTo(it) }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("ru", "RU")) ?: TextToSpeech.LANG_NOT_SUPPORTED
            tts?.setSpeechRate(0.95f)
            tts?.setPitch(1.08f)
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    override fun onStop() { generationJob?.cancel(); super.onStop() }
    override fun onDestroy() { if (::engine.isInitialized) engine.destroy(); tts?.shutdown(); super.onDestroy() }
}

fun GgufMetadata.filename(): String = basic.name?.let { name ->
    basic.sizeLabel?.let { "$name-$it" } ?: name
} ?: "aurora-model-${System.currentTimeMillis()}"
