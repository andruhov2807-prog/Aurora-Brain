package com.example.llama;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;

public class AuroraGLView extends GLSurfaceView {
    private final AuroraRenderer renderer;
    private float lastX;

    public AuroraGLView(Context context) {
        super(context);
        setEGLContextClientVersion(2);
        renderer = new AuroraRenderer();
        setRenderer(renderer);
        setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
    }

    public AuroraRenderer getRenderer() {
        return renderer;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            lastX = event.getX();
            return true;
        }
        if (event.getAction() == MotionEvent.ACTION_MOVE) {
            float dx = event.getX() - lastX;
            renderer.addManualYaw(dx * 0.25f);
            lastX = event.getX();
            return true;
        }
        return true;
    }
}
