package com.example.llama;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class AuroraRenderer implements GLSurfaceView.Renderer {
    public enum Action { STAND, SQUAT, SIT, LIE, TURN, LEAN, WAVE, POINT, WALK }
    public enum Appearance { CLOTHED, UNDERWEAR, NUDE }

    private final float[] projection = new float[16];
    private final float[] view = new float[16];
    private final float[] vp = new float[16];
    private final float[] mvp = new float[16];
    private final float[] temp = new float[16];

    private int program;
    private int aPosition;
    private int uMvp;
    private int uColor;
    private FloatBuffer cubeVertices;
    private ShortBuffer cubeIndices;

    private volatile Appearance appearance = Appearance.CLOTHED;
    private volatile Action pendingAction = null;
    private volatile float manualYawDelta = 0f;

    private Action posture = Action.STAND;
    private Action tempAction = null;
    private long tempActionStart = 0L;
    private long lastFrame = 0L;
    private boolean turnQueued = false;

    private float yaw = 0f;
    private float targetYaw = 0f;
    private float rootY = 0f;
    private float targetRootY = 0f;
    private float rootX = 0f;
    private float targetRootX = 0f;
    private float leanZ = 0f;
    private float targetLeanZ = 0f;
    private float upperLegX = 0f;
    private float targetUpperLegX = 0f;
    private float kneeX = 0f;
    private float targetKneeX = 0f;

    private static final float[] SKIN = {0.82f, 0.61f, 0.52f, 1f};
    private static final float[] HAIR = {0.14f, 0.08f, 0.06f, 1f};
    private static final float[] SHIRT = {0.35f, 0.20f, 0.56f, 1f};
    private static final float[] PANTS = {0.10f, 0.13f, 0.20f, 1f};
    private static final float[] UNDER = {0.50f, 0.16f, 0.25f, 1f};
    private static final float[] SHOES = {0.08f, 0.08f, 0.09f, 1f};

    public AuroraRenderer() {
        setupCube();
    }

    public void trigger(Action action) {
        pendingAction = action;
    }

    public void setAppearance(Appearance value) {
        appearance = value;
    }

    public void addManualYaw(float delta) {
        manualYawDelta += delta;
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        GLES20.glClearColor(0.035f, 0.045f, 0.07f, 1f);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        GLES20.glEnable(GLES20.GL_CULL_FACE);

        String vertexShader =
                "attribute vec3 aPosition;" +
                "uniform mat4 uMVP;" +
                "void main(){ gl_Position = uMVP * vec4(aPosition,1.0); }";
        String fragmentShader =
                "precision mediump float;" +
                "uniform vec4 uColor;" +
                "void main(){ gl_FragColor = uColor; }";

        int vs = compileShader(GLES20.GL_VERTEX_SHADER, vertexShader);
        int fs = compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentShader);
        program = GLES20.glCreateProgram();
        GLES20.glAttachShader(program, vs);
        GLES20.glAttachShader(program, fs);
        GLES20.glLinkProgram(program);
        GLES20.glUseProgram(program);
        aPosition = GLES20.glGetAttribLocation(program, "aPosition");
        uMvp = GLES20.glGetUniformLocation(program, "uMVP");
        uColor = GLES20.glGetUniformLocation(program, "uColor");
        lastFrame = System.nanoTime();
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        GLES20.glViewport(0, 0, width, height);
        float ratio = (float) width / Math.max(1, height);
        Matrix.perspectiveM(projection, 0, 42f, ratio, 0.5f, 40f);
        Matrix.setLookAtM(view, 0,
                0f, 1.6f, 7.2f,
                0f, 1.4f, 0f,
                0f, 1f, 0f);
        Matrix.multiplyMM(vp, 0, projection, 0, view, 0);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        updatePose();
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
        GLES20.glUseProgram(program);

        float[] root = identity();
        Matrix.translateM(root, 0, 0f, rootY, 0f);
        Matrix.rotateM(root, 0, yaw, 0f, 1f, 0f);
        Matrix.rotateM(root, 0, leanZ, 0f, 0f, 1f);
        Matrix.rotateM(root, 0, rootX, 1f, 0f, 0f);

        drawCharacter(root);
        drawFloor();
    }

    private void updatePose() {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - lastFrame) / 1_000_000_000f);
        lastFrame = now;

        if (manualYawDelta != 0f) {
            targetYaw += manualYawDelta;
            manualYawDelta = 0f;
        }

        if (pendingAction != null) {
            Action a = pendingAction;
            pendingAction = null;
            if (a == Action.STAND || a == Action.SQUAT || a == Action.SIT || a == Action.LIE) {
                posture = a;
                tempAction = null;
            } else {
                tempAction = a;
                tempActionStart = System.currentTimeMillis();
                if (a == Action.TURN) turnQueued = false;
            }
        }

        switch (posture) {
            case SQUAT:
                targetRootY = -0.58f;
                targetRootX = 0f;
                targetUpperLegX = -35f;
                targetKneeX = 68f;
                break;
            case SIT:
                targetRootY = -0.70f;
                targetRootX = 0f;
                targetUpperLegX = -82f;
                targetKneeX = 82f;
                break;
            case LIE:
                targetRootY = -1.15f;
                targetRootX = 88f;
                targetUpperLegX = 0f;
                targetKneeX = 0f;
                break;
            case STAND:
            default:
                targetRootY = 0f;
                targetRootX = 0f;
                targetUpperLegX = 0f;
                targetKneeX = 0f;
                break;
        }

        targetLeanZ = 0f;
        if (tempAction != null) {
            long age = System.currentTimeMillis() - tempActionStart;
            if (tempAction == Action.TURN) {
                if (!turnQueued) {
                    targetYaw += 90f;
                    turnQueued = true;
                }
                if (age > 1400) tempAction = null;
            } else if (tempAction == Action.LEAN) {
                targetLeanZ = age < 900 ? 18f : 0f;
                if (age > 1700) tempAction = null;
            } else if (tempAction == Action.WAVE || tempAction == Action.POINT || tempAction == Action.WALK) {
                if (age > 2600) tempAction = null;
            }
        }

        float k = 1f - (float)Math.pow(0.001, dt);
        yaw = lerpAngle(yaw, targetYaw, k * 0.55f);
        rootY = lerp(rootY, targetRootY, k * 0.55f);
        rootX = lerp(rootX, targetRootX, k * 0.55f);
        leanZ = lerp(leanZ, targetLeanZ, k * 0.6f);
        upperLegX = lerp(upperLegX, targetUpperLegX, k * 0.55f);
        kneeX = lerp(kneeX, targetKneeX, k * 0.55f);
    }

    private void drawCharacter(float[] root) {
        float time = System.currentTimeMillis() * 0.001f;
        float breath = (float)Math.sin(time * 2.0f) * 0.015f;

        Appearance app = appearance;
        float[] torsoColor = app == Appearance.CLOTHED ? SHIRT : SKIN;
        float[] legColor = app == Appearance.CLOTHED ? PANTS : SKIN;

        drawBox(root, 0f, 1.72f + breath, 0f, 1.08f, 1.35f, 0.54f, 0f, 0f, 0f, torsoColor);
        drawBox(root, 0f, 0.92f, 0f, 0.88f, 0.40f, 0.50f, 0f, 0f, 0f,
                app == Appearance.CLOTHED ? PANTS : (app == Appearance.UNDERWEAR ? UNDER : SKIN));

        if (app == Appearance.UNDERWEAR) {
            drawBox(root, 0f, 1.68f, -0.01f, 1.12f, 0.32f, 0.57f, 0f, 0f, 0f, UNDER);
        }

        float[] neck = copy(root);
        Matrix.translateM(neck, 0, 0f, 2.50f, 0f);
        drawBox(neck, 0f, 0f, 0f, 0.24f, 0.30f, 0.24f, 0f, 0f, 0f, SKIN);

        float[] head = copy(root);
        Matrix.translateM(head, 0, 0f, 2.95f, 0f);
        drawBox(head, 0f, 0f, 0f, 0.72f, 0.82f, 0.68f, 0f,
                (float)Math.sin(time * 0.7f) * 4f, 0f, SKIN);
        drawBox(head, 0f, 0.20f, -0.25f, 0.78f, 0.40f, 0.28f, 0f, 0f, 0f, HAIR);

        float wave = 0f;
        float point = 0f;
        if (tempAction == Action.WAVE) wave = (float)Math.sin(time * 8f) * 28f;
        if (tempAction == Action.POINT) point = -78f;

        drawArm(root, -0.72f, 2.22f, 0f, -6f, 0f, SKIN);
        drawArm(root,  0.72f, 2.22f, 0f,  8f + wave + point, point != 0f ? -18f : 0f, SKIN);

        float walkR = 0f;
        float walkL = 0f;
        if (tempAction == Action.WALK && posture == Action.STAND) {
            walkR = (float)Math.sin(time * 6f) * 28f;
            walkL = -walkR;
        }
        drawLeg(root, -0.30f, 0.75f, upperLegX + walkL, kneeX, legColor);
        drawLeg(root,  0.30f, 0.75f, upperLegX + walkR, kneeX, legColor);
    }

    private void drawArm(float[] root, float shoulderX, float shoulderY, float shoulderZ,
                         float shoulderZRot, float shoulderXRot, float[] color) {
        float[] shoulder = copy(root);
        Matrix.translateM(shoulder, 0, shoulderX, shoulderY, shoulderZ);
        Matrix.rotateM(shoulder, 0, shoulderZRot, 0f, 0f, 1f);
        Matrix.rotateM(shoulder, 0, shoulderXRot, 1f, 0f, 0f);
        drawBox(shoulder, 0f, -0.42f, 0f, 0.30f, 0.82f, 0.30f, 0f, 0f, 0f, color);

        float[] elbow = copy(shoulder);
        Matrix.translateM(elbow, 0, 0f, -0.84f, 0f);
        drawBox(elbow, 0f, -0.36f, 0f, 0.26f, 0.70f, 0.26f, 0f, 0f, 0f, color);
        drawBox(elbow, 0f, -0.77f, 0f, 0.28f, 0.22f, 0.30f, 0f, 0f, 0f, color);
    }

    private void drawLeg(float[] root, float hipX, float hipY, float upperXRot,
                         float kneeRot, float[] color) {
        float[] hip = copy(root);
        Matrix.translateM(hip, 0, hipX, hipY, 0f);
        Matrix.rotateM(hip, 0, upperXRot, 1f, 0f, 0f);
        drawBox(hip, 0f, -0.52f, 0f, 0.38f, 1.00f, 0.42f, 0f, 0f, 0f, color);

        float[] knee = copy(hip);
        Matrix.translateM(knee, 0, 0f, -1.02f, 0f);
        Matrix.rotateM(knee, 0, kneeRot, 1f, 0f, 0f);
        drawBox(knee, 0f, -0.50f, 0f, 0.34f, 0.96f, 0.36f, 0f, 0f, 0f, color);
        drawBox(knee, 0f, -1.03f, 0.12f, 0.38f, 0.18f, 0.64f, 0f, 0f, 0f,
                appearance == Appearance.CLOTHED ? SHOES : SKIN);
    }

    private void drawFloor() {
        float[] floor = identity();
        drawBox(floor, 0f, -1.36f, 0f, 5.5f, 0.08f, 5.5f, 0f, 0f, 0f,
                new float[]{0.08f, 0.09f, 0.12f, 1f});
    }

    private void drawBox(float[] parent, float tx, float ty, float tz,
                         float sx, float sy, float sz,
                         float rx, float ry, float rz, float[] color) {
        float[] model = copy(parent);
        Matrix.translateM(model, 0, tx, ty, tz);
        if (rx != 0f) Matrix.rotateM(model, 0, rx, 1f, 0f, 0f);
        if (ry != 0f) Matrix.rotateM(model, 0, ry, 0f, 1f, 0f);
        if (rz != 0f) Matrix.rotateM(model, 0, rz, 0f, 0f, 1f);
        Matrix.scaleM(model, 0, sx, sy, sz);
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0);

        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0);
        GLES20.glUniform4fv(uColor, 1, color, 0);
        GLES20.glEnableVertexAttribArray(aPosition);
        cubeVertices.position(0);
        GLES20.glVertexAttribPointer(aPosition, 3, GLES20.GL_FLOAT, false, 0, cubeVertices);
        cubeIndices.position(0);
        GLES20.glDrawElements(GLES20.GL_TRIANGLES, 36, GLES20.GL_UNSIGNED_SHORT, cubeIndices);
        GLES20.glDisableVertexAttribArray(aPosition);
    }

    private int compileShader(int type, String code) {
        int shader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, code);
        GLES20.glCompileShader(shader);
        return shader;
    }

    private void setupCube() {
        float[] v = {
                -0.5f,-0.5f,-0.5f,  0.5f,-0.5f,-0.5f,  0.5f, 0.5f,-0.5f, -0.5f, 0.5f,-0.5f,
                -0.5f,-0.5f, 0.5f,  0.5f,-0.5f, 0.5f,  0.5f, 0.5f, 0.5f, -0.5f, 0.5f, 0.5f
        };
        short[] idx = {
                0,1,2, 0,2,3,
                4,6,5, 4,7,6,
                0,4,5, 0,5,1,
                3,2,6, 3,6,7,
                1,5,6, 1,6,2,
                0,3,7, 0,7,4
        };
        cubeVertices = ByteBuffer.allocateDirect(v.length * 4)
                .order(ByteOrder.nativeOrder()).asFloatBuffer();
        cubeVertices.put(v).position(0);
        cubeIndices = ByteBuffer.allocateDirect(idx.length * 2)
                .order(ByteOrder.nativeOrder()).asShortBuffer();
        cubeIndices.put(idx).position(0);
    }

    private float[] identity() {
        float[] m = new float[16];
        Matrix.setIdentityM(m, 0);
        return m;
    }

    private float[] copy(float[] source) {
        float[] m = new float[16];
        System.arraycopy(source, 0, m, 0, 16);
        return m;
    }

    private float lerp(float a, float b, float t) {
        return a + (b - a) * Math.max(0f, Math.min(1f, t));
    }

    private float lerpAngle(float a, float b, float t) {
        return lerp(a, b, t);
    }
}
