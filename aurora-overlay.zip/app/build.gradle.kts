plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.jetbrains.kotlin.android)
}
android {
    namespace = "com.example.llama"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.aurora.brain"
        minSdk = 33
        targetSdk = 36
        versionCode = 3
        versionName = "0.3-offline-brain"
        vectorDrawables { useSupportLibrary = true }
    }
    buildTypes {
        debug { isMinifyEnabled = false }
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
dependencies {
    implementation(libs.bundles.androidx)
    implementation(libs.material)
    implementation(project(":lib"))
}
